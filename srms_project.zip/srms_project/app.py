from flask import Flask, render_template, request, redirect, url_for, flash
import mysql.connector

app = Flask(__name__)
app.secret_key = "srms_secret_key"

# Database Connection
conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="srms_db"
)
cursor = conn.cursor(dictionary=True)

# Home / Login Page
@app.route('/')
def index():
    return render_template('index.html')

# Dashboard
@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html')

# Add Student
@app.route('/add_student', methods=['GET', 'POST'])
def add_student():
    if request.method == 'POST':
        name = request.form['name']
        roll_no = request.form['roll_no']
        course = request.form['course']
        marks = request.form['marks']
        cursor.execute(
            "INSERT INTO students (name, roll_no, course, marks) VALUES (%s, %s, %s, %s)",
            (name, roll_no, course, marks)
        )
        conn.commit()
        flash("✅ Student added successfully!")
        return redirect(url_for('view_students'))   # ✅ FIXED
    return render_template('add_student.html')

# View Students
@app.route('/view_students')   # ✅ Changed to plural
def view_students():
    cursor.execute("SELECT * FROM students")
    students = cursor.fetchall()
    return render_template('view_students.html', students=students)

# Update Student
@app.route('/update_student/<int:id>', methods=['GET', 'POST'])
def update_student(id):
    cursor.execute("SELECT * FROM students WHERE id=%s", (id,))
    student = cursor.fetchone()
    if request.method == 'POST':
        name = request.form['name']
        roll_no = request.form['roll_no']
        course = request.form['course']
        marks = request.form['marks']
        cursor.execute("""
            UPDATE students SET name=%s, roll_no=%s, course=%s, marks=%s WHERE id=%s
        """, (name, roll_no, course, marks, id))
        conn.commit()
        flash("✅ Student updated successfully!")
        return redirect(url_for('view_students'))   # ✅ FIXED
    return render_template('update_student.html', student=student)

# Delete Student
@app.route('/delete_student/<int:id>')
def delete_student(id):
    cursor.execute("DELETE FROM students WHERE id=%s", (id,))
    conn.commit()
    flash("🗑️ Student deleted successfully!")
    return redirect(url_for('view_students'))   # ✅ FIXED

if __name__ == "__main__":
    app.run(debug=True)
